﻿using System.Reflection;
[assembly: AssemblyTitle("Majestic Companion")]
[assembly: AssemblyDescription("Companion — desktop tools for games, work and everyday tasks")]
[assembly: AssemblyProduct("Majestic Companion")]
[assembly: AssemblyVersion("0.13.5.0")]
[assembly: AssemblyFileVersion("0.13.5.0")]
